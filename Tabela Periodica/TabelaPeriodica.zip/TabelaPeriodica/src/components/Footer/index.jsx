import styles from "./Footer.module.css";

function Footer (){
    return (
        <footer className={styles.footer}>
            <p>&copy; Todos os direitos reservados Química.Br 2024</p>
        </footer>
    );
};
export default Footer;